print("Ingrese una expresión matemática:")
if let input = readLine() {
    var numeros: [Double] = []
    var operadores: [Character] = []
    var numeroActual: Double? = nil
    
    // Separar números y operadores
    for caracter in input {
        if let numero = Double(String(caracter)) {
            if let actual = numeroActual {
                //agrega un nuevo dígito al número actual multiplicando por 10 y sumando el nuevo dígito. 
                //Ejemplo: si el número actual es 2 y se encuentra el dígito 3, se actualiza a 23 y se continúa
                numeroActual = actual * 10 + numero
            } else {
                numeroActual = numero
            }
        } else {
            if let numero = numeroActual {
                numeros.append(numero)
                numeroActual = nil
            }
            if caracter != " " {
                operadores.append(caracter)
            }
        }
    }
    if let numero = numeroActual {
        numeros.append(numero)
    }
    
    // Resolver la operación
    var resultado = numeros[0]
    for i in 0..<operadores.count {
        let operador = operadores[i]
        let numero = numeros[i + 1]
        switch operador {
        case "+":
            resultado += numero
        case "-":
            resultado -= numero
        case "*":
            resultado *= numero
        case "/":
            resultado /= numero
        default:
            break
        }
    }
    
    // Mostrar resultado y cadenas separadas
    print("Números: \(numeros)")
    print("Operadores: \(operadores)")
    print("Resultado: \(resultado)")
}