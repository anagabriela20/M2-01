// Función para realizar la suma
func sumar(_ eNumero1: Float, _ eNumero2: Float) -> Float {
    return eNumero1 + eNumero2
}

// Función para realizar la resta
func restar(_ eNumero1: Float, _ eNumero2: Float) -> Float {
    return eNumero1 - eNumero2
}

// Función para realizar la multiplicación
func multiplicar(_ eNumero1: Float, _ eNumero2: Float) -> Float {
    return eNumero1 * eNumero2
}

// Función para realizar la división
func dividir(_ eNumero1: Float, _ eNumero2: Float) -> Float? {
    if eNumero2 == 0 {
        return nil
    } else {
        return eNumero1 / eNumero2
    }
}

// Solicitar al usuario que ingrese el primer número
print("Ingrese el primer número:")
let eNumero1 = Float(readLine()!)!

// Solicitar al usuario que ingrese el segundo número
print("Ingrese el segundo número:")
let eNumero2 = Float(readLine()!)!

// Solicitar al usuario que ingrese la operación a realizar
print("Ingrese la operación a realizar (+, -, *, /):")
let operacion = readLine()!

// Realizar la operación seleccionada
var resultado: Float?
switch operacion {
case "+":
    resultado = sumar(eNumero1, eNumero2)
case "-":
    resultado = restar(eNumero1, eNumero2)
case "*":
    resultado = multiplicar(eNumero1, eNumero2)
case "/":
    resultado = dividir(eNumero1, eNumero2)
default:
    print("La operación ingresada no es válida.")
}

// Mostrar el resultado por pantalla
if let resultado = resultado {
    print("El resultado es: \(resultado)")
} else {
    print("No se puede realizar la división, el segundo número debe ser distinto de cero.")
}
