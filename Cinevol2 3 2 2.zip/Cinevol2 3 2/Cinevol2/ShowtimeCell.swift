//
//  ShowtimeCell.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 23/05/23.
//

import UIKit

class ShowtimeCell: UICollectionViewCell {
    
    @IBOutlet var lblShowitme: UILabel!
    
    
    func setup(with movieShow : MovieShow)
    {
        lblShowitme.text = movieShow.showTime
    }
    
}
