//
//  Tickets.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 23/05/23.
//

import UIKit

class Tickets: UIViewController {

    @IBOutlet var lblInfo: UILabel!
    @IBOutlet var stpTickets: UIStepper!
    @IBOutlet var lblNumberOfTickets: UILabel!
    @IBOutlet var stpChildrenTickets: UIStepper!
    @IBOutlet var lblNumberOfChildrenTickets: UILabel!
    
    var movieShow: MovieShow?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let movieShow = movieShow {
            
            if let movieName = movies.first(where: { movie in
                movie.id == movieShow.movieId})?.title {
                lblInfo.text = "Boletos para \(movieName) a las \(movieShow.showTime)"
            }
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Next(_ sender: UIButton) {
        
        performSegue(withIdentifier: "ticketsToRoom", sender: nil)
        
    }
    @IBAction func stpTicketsAction(_ sender: UIStepper) {
        
        lblNumberOfTickets.text = String(Int(sender.value))
    }
    
    @IBAction func stpChildrenTicketsAction(_ sender: UIStepper) {
        
        lblNumberOfChildrenTickets.text = String(Int(sender.value))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ticketsToRoom" {
            
            if let vc = segue.destination as? RoomViewController {
                
                vc.numberOfSeatsToTake = (Int(lblNumberOfTickets.text!)! + Int(lblNumberOfChildrenTickets.text!)!)
                
                vc.movieShow = self.movieShow
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
