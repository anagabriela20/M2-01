//
//  DetalleVC.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 12/05/23.
//

import UIKit

class DetalleVC: UIViewController {

    @IBOutlet var showtimeCollectionView: UICollectionView!
    @IBOutlet weak var imagenPelicula: UIImageView!
    @IBOutlet var movieTitle: UILabel!
    
    @IBOutlet weak var movieDescription: UILabel!
    
    @IBOutlet weak var movieClassification: UILabel!
    
    
    
    var movie: Movie?
    var movieShows = [MovieShow]()
    var selectedShow: MovieShow?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showtimeCollectionView.delegate = self
        showtimeCollectionView.dataSource = self
        
        if let movie = movie {
            imagenPelicula.image = movie.images[0]
            movieTitle.text = movie.title
            movieDescription.text = movie.description
            movieClassification.text = movie.classification
            
            self.movieShows = moviesShows.filter({ movieShow in
                
                movieShow.movieId == movie.id
            })
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "MovieToTickets" {
            
            if let vc = segue.destination as? Tickets {
                
                vc.movieShow = selectedShow
            }
        }
    }
}

extension DetalleVC: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movieShows.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "shows", for: indexPath) as! ShowtimeCell
        cell.setup(with: movieShows[indexPath.row])
        cell.lblShowitme.layer.cornerRadius = 10
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        selectedShow = movieShows[indexPath.row]
        
        performSegue(withIdentifier: "MovieToTickets", sender: nil)
    }
}
