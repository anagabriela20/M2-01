//
//  MovieFeed.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 16/05/23.
//

import Foundation
import UIKit

struct MovieFeed {
    let image: UIImage
    let largeImage: UIImage
    let title: String
    let description: String
    let classification: String
}

let moviesFeed: [MovieFeed] = [
    MovieFeed(image: UIImage(named: "transformers-small")!, largeImage: UIImage(named: "transformers")!, title: "Transformers", description: "Descripción de Transformers", classification: "Clasificación de Transformers"),
   MovieFeed(image: UIImage(named: "miles-small")!, largeImage: UIImage(named: "miles")!, title: "Miles", description: "Descripción de Miles", classification: "Clasificación de Miles"),
   MovieFeed(image: UIImage(named: "lalaland-small")!, largeImage: UIImage(named: "lalaland")!, title: "La La Land", description: "Descripción de La La Land", classification: "Clasificación de La La Land"),
        MovieFeed(image: UIImage(named: "avengers-small")!, largeImage: UIImage(named: "avengers")!,title: "Avengers", description: "Descriopcion", classification: "A"),
        MovieFeed(image: UIImage(named: "bridesmaids-small")!, largeImage: UIImage(named: "bridesmaids")!, title: "Bridesmaids", description: "khsijadjskjkdjjs", classification: "B-15"),
        MovieFeed(image: UIImage(named: "guardians-small")!, largeImage: UIImage(named: "guardians")!, title: "Guardians of the Galaxy vol.1", description: "aaa", classification: "P-13"),
        MovieFeed(image: UIImage(named: "harrypotter1-small")!, largeImage: UIImage(named: "harrypotter1")!, title: "Harry Potter y la piedra filosofal", description: "oidahiojdio", classification: "B"),
        MovieFeed(image: UIImage(named: "titanic-small")!, largeImage: UIImage(named: "titanic")!, title: "Titanic", description: "ioduvfhuodsf", classification: "B-15"),
        MovieFeed(image: UIImage(named: "zootopia-small")!, largeImage: UIImage(named: "zootopia")!, title: "Zootopia", description: "odshukdshsdo", classification: "A")
]
