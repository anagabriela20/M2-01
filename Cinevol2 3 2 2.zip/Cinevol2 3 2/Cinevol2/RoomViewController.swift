//
//  RoomViewController.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 23/05/23.
//

import UIKit

class RoomViewController: UIViewController {

    @IBOutlet var spinner: UIActivityIndicatorView!
    @IBOutlet var outletButton: UIButton!
    @IBOutlet var seatsCollectionView: UICollectionView!
    
    var movieShow : MovieShow?
    var numberOfSeatsToTake : Int?
    var selectedSeats = [Int]()
    var movieShowIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        spinner.hidesWhenStopped = true
        
        seatsCollectionView.delegate = self
        seatsCollectionView.dataSource = self

        if let movieShowIndex = moviesShows.firstIndex(where: { movieShow in
            movieShow.id == self.movieShow!.id
        }){
            self.movieShowIndex = movieShowIndex
            
            
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func takeSeats(_ sender: UIButton) {
        
        spinner.startAnimating()
        
        selectedSeats.forEach { seatId in
            
            moviesShows[movieShowIndex!].seats[seatId].status = .ocuppied
        }
        
        spinner.stopAnimating()
        self.navigationController?.popViewController(animated: true)
        
        
    }
    

}

extension RoomViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return movieShow!.seats.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "seats", for: indexPath) as! SeatCell
        
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 8
        
        cell.setUp(with: moviesShows[movieShowIndex!].seats[indexPath.row])

            
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            
            let selectedSeat = indexPath.row
            
            if moviesShows[movieShowIndex!].seats[selectedSeat].status == .ocuppied || moviesShows[movieShowIndex!].seats[selectedSeat].status == .reserved {
                if let index = selectedSeats.firstIndex(of: selectedSeat) {
                    selectedSeats.remove(at: index)
                    moviesShows[movieShowIndex!].seats[selectedSeat].status = .empty
                }
            } else if selectedSeats.contains(selectedSeat) {
                selectedSeats.removeAll { $0 == selectedSeat }
                moviesShows[movieShowIndex!].seats[selectedSeat].status = .empty
            } else if selectedSeats.count < numberOfSeatsToTake ?? 0 {
                selectedSeats.append(selectedSeat)
                moviesShows[movieShowIndex!].seats[selectedSeat].status = .reserved
        
            }
            
            UIView.animate(withDuration: 0.3, animations: {
                collectionView.reloadItems(at: [indexPath])
            }) { _ in
                collectionView.reloadData()
            }
            
            outletButton.isEnabled = selectedSeats.count == numberOfSeatsToTake
        }

}
