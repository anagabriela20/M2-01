//
//  Movie.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 09/05/23.
// Clase que te muestra las películas y el carrusel

import Foundation
import UIKit

struct Movie {
    let id: Int
    let images: [UIImage]
    let title: String
    let description: String
    let classification: String
}

let movies: [Movie] = [
    
    Movie(id:1, images: [UIImage(named: "imagen1")!, UIImage(named: "imagen1.1")!], title: "Encanto", description: "Cuenta la historia de una familia extraordinaria, los Madrigal, que viven escondidos en las montañas de Colombia, en una casa mágica situada en un enclave maravilloso llamado Encanto. ", classification: "Clasif. A"),
    Movie(id:2, images: [UIImage(named: "imagen2")!, UIImage(named: "imagen2.1")!], title: "Coco", description: "Miguel es un aspirante a cantante y guitarrista autodidacta que sueña con seguir los pasos de su ídolo, Ernesto de la Cruz, el músico más famoso de la historia de México. Pero la familia de Miguel ha prohibido la música. ", classification: "Clasif. A"),
    Movie(id:3, images: [UIImage(named: "imagen3")!, UIImage(named: "imagen3.1")!], title: "Lucas", description: "Un niño monstruo marino con la capacidad de asumir una forma humana mientras está en tierra, que explora la ciudad de Portorosso con su nuevo amigo Alberto Scorfano, experimentando un verano que cambia su vida. ", classification: "Clasif. A"),
    Movie(id:4, images: [UIImage(named: "imagen4")!, UIImage(named: "imagen4.1")!], title: "Tangled", description: "Cuenta la historia de la perdida princesa Rapunzel, que anhela dejar su torre aislada por una aventura. Contra los deseos de su madrastra, acepta la ayuda de un apuesto intruso, Flynn Rider, para sacarla al mundo que nunca ha visto.", classification: "Clasif. A"),
    Movie(id:5, images: [UIImage(named: "imagen5")!, UIImage(named: "imagen5.1")!], title: "Raya", description: "Una joven guerrera nos adentra en una aventura para salvar a la humanidad de fuerzas malignas, de la mano de grandes amigos. ", classification: "Clasif. A"),
    Movie(id:6, images: [UIImage(named: "imagen6")!, UIImage(named: "imagen6.1")!], title: "Red", description: "Se presenta a Mei Lee, una niña de 13 años segura de sí misma que se debate entre ser la hija obediente de su madre y el caos de la adolescencia. ", classification: "Clasif. A"),
]

//Te muestra el carrucel

let popularMovies: [Movie] = [
    
    Movie(id:1, images: [UIImage(named: "imagen1")!, UIImage(named: "imagen1.1")!], title: "Encanto", description: "Cuenta la historia de una familia extraordinaria, los Madrigal, que viven escondidos en las montañas de Colombia, en una casa mágica situada en un enclave maravilloso llamado Encanto. ", classification: "Clasif. A"),
    Movie(id:2, images: [UIImage(named: "imagen2")!, UIImage(named: "imagen1.2")!], title: "Coco", description: "Miguel es un aspirante a cantante y guitarrista autodidacta que sueña con seguir los pasos de su ídolo, Ernesto de la Cruz, el músico más famoso de la historia de México. Pero la familia de Miguel ha prohibido la música. ", classification: "Clasif. A"),
    Movie(id:3, images: [UIImage(named: "imagen3")!, UIImage(named: "imagen1.3")!], title: "Lucas", description: "Un niño monstruo marino con la capacidad de asumir una forma humana mientras está en tierra, que explora la ciudad de Portorosso con su nuevo amigo Alberto Scorfano, experimentando un verano que cambia su vida. ", classification: "Clasif. A"),
    Movie(id:4, images: [UIImage(named: "imagen4")!, UIImage(named: "imagen1.4")!], title: "Tangled", description: "Cuenta la historia de la perdida princesa Rapunzel, que anhela dejar su torre aislada por una aventura. Contra los deseos de su madrastra, acepta la ayuda de un apuesto intruso, Flynn Rider, para sacarla al mundo que nunca ha visto.", classification: "Clasif. A"),
    Movie(id:5, images: [UIImage(named: "imagen5")!, UIImage(named: "imagen1.5")!], title: "Raya", description: "Una joven guerrera nos adentra en una aventura para salvar a la humanidad de fuerzas malignas, de la mano de grandes amigos. ", classification: "Clasif. A"),
    Movie(id:6, images: [UIImage(named: "imagen6")!, UIImage(named: "imagen1.6")!], title: "Red", description: "Se presenta a Mei Lee, una niña de 13 años segura de sí misma que se debate entre ser la hija obediente de su madre y el caos de la adolescencia. ", classification: "Clasif. A"),
]
